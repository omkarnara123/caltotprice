package com.app;

import static org.junit.Assert.*;

import java.text.ParseException;

import org.junit.Test;

public class TestCases {

	@Test
	public void testA() throws ParseException {
		
		CalculatePrice c = new CalculatePrice();
		MyThread t1 = new MyThread(c);
		t1.start();
		
		//c.calTotalPrice();
		
		System.out.println(" competed ");
	}

	
	@Test
	public void testB() throws ParseException {
		
		CalculatePrice c = new CalculatePrice();
		MyThread t1 = new MyThread(c);
		t1.start();
		
		//c.calTotalPrice();
		
		System.out.println(" competed ");
	}
	
	@Test
	public void testC() throws ParseException {
		
		CalculatePrice c = new CalculatePrice();
		MyThread t1 = new MyThread(c);
		t1.start();
		
		//c.calTotalPrice();
		
		System.out.println(" competed ");
	}
}
