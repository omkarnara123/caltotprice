package com.app;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class CalculatePriceTest {

	public static void main(String[] args) throws ParseException {

		int priceValue = 0;
		int incementLoopPriceValue = 0;
		int incementPriceValue = 0;
        
		 Scanner scanner = new Scanner(System.in);

		 System.out.println("Please enter Number of components are used for preparing cycle ");
	     System.out.println("Please enter your input (Number Only): ");
	     int noOfComponents = scanner.nextInt();
	     System.out.println("User Input from console is noOfComponents : " + noOfComponents);

	     for(int i = 0;i<noOfComponents;i++) {
	     System.out.println("Please enter the component name and price(Please give , between them.eg: (handle,200): ");
	     String nameAndPrice = scanner.next();
	     
	     String[] split = nameAndPrice.split(",");
	     
	     //
	     if(split[0].equalsIgnoreCase("tyre")) {
	    	 //
	    	 	String checkStDt="01/01/2016";  
	    	    Date sdate1=new SimpleDateFormat("dd/MM/yyyy").parse(checkStDt);  
	    	 
	    	    String checkEnDt="01/11/2016";  
	    	    Date edate1=new SimpleDateFormat("dd/MM/yyyy").parse(checkEnDt);
	    	 
	    	 //
	    	 
	    	 
	    	 //stdate
	    	 System.out.println("Please enter start date (dd/MM/yyyy) format only of tyre :: ");
		     String sDate1 = scanner.next();
		     Date stdate=new SimpleDateFormat("dd/MM/yyyy").parse(sDate1);  
		     System.out.println(" stdate is  : " + stdate);
		     
		     
		     //endate
		     System.out.println("Please enter end date date (dd/MM/yyyy) format only of tyre :: ");
		     String enDate1 = scanner.next();
		     Date endate=new SimpleDateFormat("dd/MM/yyyy").parse(enDate1);
		     System.out.println(" endate is  : " + endate);
		     
		     if(stdate.after(sdate1) && endate.before(edate1) && endate.before(edate1) ) {
		    	 
		    	 priceValue = 200;
		     }else {
		    	 priceValue = 230;
		     }
	    	 
	     }
	     //
	     else {
	     String price = split[1];
	     priceValue = Integer.parseInt(price);
	     }
	     
	     incementLoopPriceValue = priceValue;
	     
	     incementPriceValue += incementLoopPriceValue;
	     
	     System.out.println("incementPriceValue in loop is ::"+incementPriceValue);
	     }
	     
	     System.out.println("Total Price of the car is   ::"+incementPriceValue);

	   
        
		
		
	}

}
