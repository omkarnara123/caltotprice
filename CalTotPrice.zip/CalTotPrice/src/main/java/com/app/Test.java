package com.app;

public class Test {

	public static void main(String[] args) {
		System.out.println("hi hello ");
		CalculatePrice c = new CalculatePrice();
		MyThread t1 = new MyThread(c);
		t1.start();
	}

	
}
