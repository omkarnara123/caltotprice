package com.app;

import java.text.ParseException;

public class MyThread extends Thread{

	CalculatePrice c;
	
	public MyThread(CalculatePrice c) {
		this.c = c;
	}
	
	public void run() {
		
		try {
			c.calTotalPrice();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
}
